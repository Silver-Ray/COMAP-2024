%%
A = [1 1
    1 1/4
    1 -1
    -1/4 -1
    -1 -1
    -1 1];
b = [2 1 2 1 -1 2];
f = [-1 -1/3];
x = linprog(f,A,b)


%%
A = [1 1
    1 1/4
    1 -1
    -1/4 -1
    -1 -1
    -1 1];
b = [2 1 2 1 -1 2];
Aeq = [1 1/4];
beq = 1/2;
f = [-1 -1/3];
x = linprog(f,A,b,Aeq,beq)

%%
A = [1 1
    1 1/4
    1 -1
    -1/4 -1
    -1 -1
    -1 1];
b = [2 1 2 1 -1 2];
Aeq = [1 1/4];
beq = 1/2;
lb = [-1,-0.5];
ub = [1.5,1.25];
f = [-1 -1/3];
x = linprog(f,A,b,Aeq,beq,lb,ub)

%%
f = [8;1];
intcon = 2;
A = [-1,-2;
    -4,-1;
    2,1];
b = [14;-33;20];
x = intlinprog(f,intcon,A,b)

%%
f = [-3;-2;-1];
intcon = 3;
A = [1,1,1];
b = 7;
Aeq = [4,2,1];
beq = 12;
lb = zeros(3,1);
ub = [Inf;Inf;1];
x = intlinprog(f,intcon,A,b,Aeq,beq,lb,ub)

%%
Aeq = [22    13    26    33    21     3    14    26
    39    16    22    28    26    30    23    24
    18    14    29    27    30    38    26    26
    41    26    28    36    18    38    16    26];
beq = [ 7872
       10466
       11322
       12058];
   N = 8;
lb = zeros(N,1);
intcon = 1:N;
f = [2    10    13    17     7     5     7     3];
[x1,fval1,exitflag1,output1] = intlinprog(f,intcon,[],[],Aeq,beq,lb);
x0 = [8 62 23 103 53 84 46 34];
[x2,fval2,exitflag2,output2] = intlinprog(f,intcon,[],[],Aeq,beq,lb,[],x0);
% options = optimoptions('intlinprog','RootLPAlgorithm','dual-simplex');
% x= intlinprog(f,intcon,[],[],Aeq,beq,lb,[],options)

%%
fun = @sin;
x1 = 0;
x2 = 2*pi;
x = fminbnd(fun,x1,x2)

%%
x = fminbnd(@scalarobjective,1,3)


%%
a = 9/7;
fun = @(x)sin(x-a);
x1 = 0;
x2 = 2*pi;
options = optimset('Display','iter','PlotFcns',@optimplotfval);
%optimplotx
%optimplotfunccount
%optimplotfval
[x,fval,exitflag,output] = fminbnd(fun,x1,x2,options)

%%
fun = @(x)3*x(1)^2 + 2*x(1)*x(2) + x(2)^2 - 4*x(1) + 5*x(2);
x0 = [1,1];
[x,fval] = fminunc(fun,x0)

%%
fun = @(x)x(1)+x(2);
x0 = [1,1];
[x,fval] = fminunc(fun,x0)

%%
fun = @(x)x(1)*exp(-(x(1)^2 + x(2)^2)) + (x(1)^2 + x(2)^2)/20;
x0 = [1,2];
options = optimoptions(@fminunc,'Display','iter','Algorithm','quasi-newton','PlotFcns',@optimplotstepsize);
%optimplotx
%optimplotfunccount
%optimplotfval
%optimplotstepsize
%optimplotfirstorderopt
[x,fval,exitflag,output] = fminunc(fun,x0,options)

%%
fun = @(x)100*(x(2)-x(1)^2)^2 + (1-x(1))^2;
x0 = [0.5,0];
A = [1,2];
b = 1;
Aeq = [2,1];
beq = 1;
x = fmincon(fun,x0,A,b,Aeq,beq)

%%
fun = @(x)100*(x(2)-x(1)^2)^2 + (1-x(1))^2;
lb = [0,0.2];
ub = [0.5,0.8];
A = [];
b = [];
Aeq = [];
beq = [];
x0 = [1/4,1/4];
nonlcon = @circlecon;
x = fmincon(fun,x0,A,b,Aeq,beq,lb,ub,nonlcon)
%optimplotx
%optimplotfunccount
%optimplotfval
%optimplotfvalconstr
%optimplotconstrviolation
%optimplotstepsize
%optimplotfirstorderopt

%%
fun = @(x)100*(x(2) - x(1)^2)^2 + (1 - x(1))^2;
x0 = [-1.2,1];
x = fminsearch(fun,x0)

%%
options = optimset('Display','iter','PlotFcns',@optimplotfval);
fun = @(x)100*(x(2) - x(1)^2)^2 + (1 - x(1))^2;
x0 = [-1.2,1];
x = fminsearch(fun,x0,options)
%optimplotx
%optimplotfunccount
%optimplotfval