%% sin
x = 0:pi/4:2*pi; 
v = sin(x);
xq = 0:pi/16:2*pi;
vq1 = interp1(x,v,xq);
subplot(211)
plot(x,v,'o',xq,vq1,':.');
xlim([0 2*pi]);
title('(Default) Linear Interpolation');
subplot(212)
vq2 = interp1(x,v,xq,'spline');
plot(x,v,'o',xq,vq2,':.');
xlim([0 2*pi]);
title('Spline Interpolation');

%% randn
x = 1:100; 
v = randn(1,100);
xq = 1:0.1:100;
vq1 = interp1(x,v,xq);
subplot(211)
plot(x,v,'o',xq,vq1,':.');
xlim([1 100]);
title('(Default) Linear Interpolation');
subplot(212)
vq2 = interp1(x,v,xq,'spline');
plot(x,v,'o',xq,vq2,':.');
xlim([1 100]);
title('Spline Interpolation');

%% ���-1
x = [1 2 3 4 5];
v = [12 16 31 10 6];
xq = [0 0.5 1.5 5.5 6];
vq1 = interp1(x,v,xq,'pchip')
vq2 = interp1(x,v,xq,'linear')
vq3 = interp1(x,v,xq,'linear','extrap')
plot(xq,vq1)
hold on
plot(xq,vq2)
plot(xq,vq3)
scatter(x,v)

%% 2D
[X,Y] = meshgrid(-3:3);
V = peaks(X,Y);
subplot(311)
surf(X,Y,V)
title('Original Sampling');
[Xq,Yq] = meshgrid(-3:0.25:3);
Vq = interp2(X,Y,V,Xq,Yq);
subplot(312)
surf(Xq,Yq,Vq);
title('Linear Interpolation Using Finer Grid');
subplot(313)
Vq = interp2(X,Y,V,Xq,Yq,'cubic');
surf(Xq,Yq,Vq);
title('Cubic Interpolation Over Finer Grid');

%%3D
[X,Y,Z,V] = flow(10);
subplot(311)
slice(X,Y,Z,V,[6 9],2,0);shading flat
[Xq,Yq,Zq] = meshgrid(.1:.025:10,-3:.025:3,-3:.025:3);
Vq = interp3(X,Y,Z,V,Xq,Yq,Zq);
subplot(312)
slice(Xq,Yq,Zq,Vq,[6 9],2,0);shading flat
Vq = interp3(X,Y,Z,V,Xq,Yq,Zq,'cubic');
subplot(313)
slice(Xq,Yq,Zq,Vq,[6 9],2,0);shading flat

%% fft
dx = 3*pi/30;
x = 0:dx:3*pi;
f = sin(x).^2 .* cos(x);
plot(x,f,'o')
N = 200;
y = interpft(f,N);
dy = dx*length(x)/N;
x2 = 0:dy:3*pi;
y = y(1:length(x2));
hold on
plot(x2,y,'.')
title('FFT Interpolation of Periodic Function')

%% fit
load census;
f=fit(cdate,pop,'poly2')
plot(f,cdate,pop)

%% fit-2D
load franke
sf = fit([x, y],z,'poly23')
plot(sf,[x,y],z)

%%
load census
plot(cdate,pop,'o')
ft = fittype('a*(x-b)^2','independent','x','coefficients',{'a','b'});
[curve2,gof2] = fit(cdate,pop,ft)
hold on
plot(curve2,'m')
hold off

%% 
load census;
ft = fittype('a*x+b*x^2+c');
f=fit(cdate,pop,ft,'Lower',[-100,-100,-100],'Upper',[Inf,Inf,Inf],'StartPoint',[1,3,5],'Algorithm','Levenberg-Marquardt')
plot(f,cdate,pop)

% load census;
% f=fit(cdate,pop,'poly2','Lower',[-100,-100,-100],'Upper',[Inf,Inf,Inf],'StartPoint',[1,3,5])
% plot(f,cdate,pop)

%% gof
load franke
[sf,gof] = fit([x, y],z,'poly23');
gof
% gof.sse
% gof.rsquare
% gof.dfe
% gof.adjrsquare
% gof.rmse

%% lsqcurvefit
xdata = [0.9 1.5 13.8 19.8 24.1 28.2 35.2 60.3 74.6 81.3];
ydata = [455.2 428.6 124.1 67.3 43.2 28.1 13.1 -0.4 -1.3 -1.5];
fun = @(x,xdata)x(1)*exp(x(2)*xdata);
x0 = [100,-1];
options = optimoptions('lsqcurvefit','Algorithm','levenberg-marquardt');
lb = [-500,-500];
ub = [500,500];
x = lsqcurvefit(fun,x0,xdata,ydata,lb,ub,options)
times = linspace(xdata(1),xdata(end));
plot(xdata,ydata,'ko',times,fun(x,times),'b-')
legend('Data','Fitted exponential')
title('Data and Fitted Curve')

%% lsqcurvefit
xdata = [0.9 1.5 13.8 19.8 24.1 28.2 35.2 60.3 74.6 81.3];
ydata = [455.2 428.6 124.1 67.3 43.2 28.1 13.1 -0.4 -1.3 -1.5];
fun = @(x)x(1)*exp(x(2)*xdata)-ydata;
fun0 = @(x,xdata)x(1)*exp(x(2)*xdata);
x0 = [100,-1];
options = optimoptions('lsqcurvefit','Algorithm','levenberg-marquardt');
lb = [-500,-500];
ub = [500,500];
x = lsqnonlin(fun,x0,lb,ub,options)
times = linspace(xdata(1),xdata(end));
plot(xdata,ydata,'ko',times,fun0(x,times),'b-')
legend('Data','Fitted exponential')
title('Data and Fitted Curve')

%% toolbox
x=0:0.01:10*pi;
y=1+2*cos(x+pi/6);