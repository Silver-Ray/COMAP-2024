%%
load fisheriris
X = meas(:,3:4);
Y = species;
tabulate(Y)
Mdl = fitcnb(X,Y,'ClassNames',{'setosa','versicolor','virginica'})
label = predict(Mdl,X);
setosaIndex = strcmp(Mdl.ClassNames,'setosa');
estimates = Mdl.DistributionParameters{setosaIndex,1}
figure
gscatter(X(:,1),X(:,2),Y);
h = gca;
cxlim = h.XLim;
cylim = h.YLim;
hold on
Params = cell2mat(Mdl.DistributionParameters); 
Mu = Params(2*(1:3)-1,1:2);
Sigma = zeros(2,2,3);
for j = 1:3
    Sigma(:,:,j) = diag(Params(2*j,:)).^2; % Create diagonal covariance matrix
    xlim = Mu(j,1) + 4*[-1 1]*sqrt(Sigma(1,1,j));
    ylim = Mu(j,2) + 4*[-1 1]*sqrt(Sigma(2,2,j));
    f = @(x,y) arrayfun(@(x0,y0) mvnpdf([x0 y0],Mu(j,:),Sigma(:,:,j)),x,y);
    fcontour(f,[xlim ylim]) % Draw contours for the multivariate normal distributions 
end
h.XLim = cxlim;
h.YLim = cylim;
title('Naive Bayes Classifier -- Fisher''s Iris Data')
xlabel('Petal Length (cm)')
ylabel('Petal Width (cm)')
legend('setosa','versicolor','virginica')
hold off


%%
load ionosphere
X = X(:,3:end);
rng('default') 
CVMdl = fitcnb(X,Y,'ClassNames',{'b','g'},'CrossVal','on')
CVMdl.Trained{1}
genError = kfoldLoss(CVMdl)


%% 
load ionosphere
MdlDefault = fitctree(X,Y,'CrossVal','on');
numBranches = @(x)sum(x.IsBranch);
mdlDefaultNumSplits = cellfun(numBranches, MdlDefault.Trained);
histogram(mdlDefaultNumSplits)
view(MdlDefault.Trained{1},'Mode','graph')
Mdl7 = fitctree(X,Y,'MaxNumSplits',7,'CrossVal','on');
%���ָ�������Ϊ 7
view(Mdl7.Trained{1},'Mode','graph')
classErrorDefault = kfoldLoss(MdlDefault)
classError7 = kfoldLoss(Mdl7)
label = predict(Mdl7.Trained{1},X);

%%
load fisheriris
inds = ~strcmp(species,'setosa');
X = meas(inds,3:4);
y = species(inds);
SVMModel = fitcsvm(X,y)
classOrder = SVMModel.ClassNames
sv = SVMModel.SupportVectors;
figure
gscatter(X(:,1),X(:,2),y)
hold on
plot(sv(:,1),sv(:,2),'ko','MarkerSize',10)
legend('versicolor','virginica','Support Vector')
hold off

%%
load ionosphere
SVMModel = fitcsvm(X,Y,'Standardize',true,'KernelFunction','RBF',...
    'KernelScale','auto');
CVSVMModel = crossval(SVMModel);
classLoss = kfoldLoss(CVSVMModel)
[label,score] = predict(SVMModel,X);

%%
load nlpdata
Ystats = Y == 'stats';
[Mdl,FitInfo] = fitclinear(X,Ystats)

%%
load fisheriris
X = meas;
Y = species;
Mdl = fitcecoc(X,Y)
label = predict(Mdl,X);

%%
load fisheriris
X = meas;
Y = species;
Mdl = fitcknn(X,Y,'NumNeighbors',5,'Standardize',1)

%%
load fisheriris
X = meas;
Y = species;
Mdl = fitcknn(X,Y,'NumNeighbors',3,...
    'NSMethod','exhaustive','Distance','minkowski',...
    'Standardize',1);
label = predict(Mdl,X);

%%
X = [(randn(20,2)*0.75)+1;
    (randn(20,2)*0.25)-1];
scatter(X(:,1),X(:,2));
title('Randomly Generated Data');
Z = linkage(X,'ward');
dendrogram(Z)
T = cluster(Z, 'cutoff' ,3, 'Depth' ,4); 
gscatter(X(:,1),X(:,2),T)

%%
load fisheriris
Z = linkage(meas,'average','chebychev');
T = cluster(Z,'maxclust',3);
cutoff = median([Z(end-2,3) Z(end-1,3)]);
dendrogram(Z,'ColorThreshold',cutoff)

%%
load fisheriris
X = meas(:,3:4);
figure;
plot(X(:,1),X(:,2),'k*','MarkerSize',5);
title 'Fisher''s Iris Data';
xlabel 'Petal Lengths (cm)'; 
ylabel 'Petal Widths (cm)';
[idx,C] = kmeans(X,3);
x1 = min(X(:,1)):0.01:max(X(:,1));
x2 = min(X(:,2)):0.01:max(X(:,2));
[x1G,x2G] = meshgrid(x1,x2);
XGrid = [x1G(:),x2G(:)]; % Defines a fine grid on the plot
idx2Region = kmeans(XGrid,3,'MaxIter',100,'Start',C);
figure;
gscatter(XGrid(:,1),XGrid(:,2),idx2Region,...
    [0,0.75,0.75;0.75,0,0.75;0.75,0.75,0],'..');
hold on;
plot(X(:,1),X(:,2),'k*','MarkerSize',5);
title 'Fisher''s Iris Data';
xlabel 'Petal Lengths (cm)';
ylabel 'Petal Widths (cm)'; 
legend('Region 1','Region 2','Region 3','Data','Location','SouthEast');
hold off;