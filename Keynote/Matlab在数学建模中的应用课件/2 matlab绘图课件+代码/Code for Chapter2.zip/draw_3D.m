
%%
t = 0:pi/500:40*pi;
xt = (3 + cos(sqrt(32)*t)).*cos(t);
yt = sin(sqrt(32) * t);
zt = (3 + cos(sqrt(32)*t)).*sin(t);
plot3(xt,yt,zt)
axis equal
xlabel('x(t)')
ylabel('y(t)')
zlabel('z(t)')

%%
z = linspace(0,4*pi,250);
x = 2*cos(z) + rand(1,250);
y = 2*sin(z) + rand(1,250);
scatter3(x,y,z,'filled')

%%
load count.dat
Z = count(1:10,:);
width = 0.5;
bar3(Z,width)
title('Bar Width of 0.5')

%%
load count.dat;
Y = count(1:10,:);
width = 0.5;
figure
bar3h(Y,width)
title('Width of 0.5')

%%
load carbig
X = [MPG,Weight];
hist3(X)
xlabel('MPG')
ylabel('Weight')

%%
x = [1,3,0.5,2.5,2];
pie3(x)

%%
[X,Y] = meshgrid(1:0.5:10,1:20);
Z = sin(X) + cos(Y);
C = X.*Y;
surf(X,Y,Z,C)

%%
[X,Y] = meshgrid(-5:.5:5);
Z = Y.*sin(X) - X.*cos(Y);
s = surf(X,Y,Z,'FaceAlpha',0.5)

%%
[X,Y] = meshgrid(-8:.5:8);
R = sqrt(X.^2 + Y.^2) + eps;
Z = sin(R)./R;
mesh(X,Y,Z)


%%
[X,Y] = meshgrid(-8:.5:8);
R = sqrt(X.^2 + Y.^2) + eps;
Z = sin(R)./R;
subplot(121)
mesh(X,Y,Z)
subplot(122)
surf(X,Y,Z)

%%
load('Point.mat')
x=A(:,1);y=A(:,2);z=A(:,3);
[X,Y,Z]=griddata(x,y,z,linspace(min(x),max(x))',linspace(min(y),max(y)),'v4');
contourf(X,Y,Z)
surf(X,Y,Z)

%%
x = -2:0.2:2;
y = -2:0.2:3;
[X,Y] = meshgrid(x,y);
Z = X.*exp(-X.^2-Y.^2);
contour(X,Y,Z,'ShowText','on')

%%
[X,Y,Z] = peaks;
subplot(121)
surf(X,Y,Z)
subplot(122)
surf(X,Y,Z)
view(2)

