%% 
x = 0:pi/100:2*pi;
y = sin(x);
plot(x,y)

%%
x = linspace(-2*pi,2*pi);
y1 = sin(x);
y2 = cos(x);
plot(x,y1,x,y2)

%%
Y = magic(5);
plot(Y)

%%
x = 0:pi/100:2*pi;
y1 = sin(x);
y2 = sin(x-0.25);
y3 = sin(x-0.5);
plot(x,y1,x,y2,'--',x,y3,':')

%%
x = 0:pi/10:2*pi;
y1 = sin(x);
y2 = sin(x-0.25);
y3 = sin(x-0.5);
plot(x,y1,'g',x,y2,'b--o',x,y3,'c*')

%%
x = linspace(0,10);%�ȼ���0:(10-0)/99:10
y = sin(x);
plot(x,y,'-o','MarkerIndices',1:5:length(y))

%%
x = -pi:pi/10:pi;
y = tan(sin(x)) - sin(tan(x));
plot(x,y,'--sg',...
    'LineWidth',2,...
    'MarkerSize',10,...
    'MarkerEdgeColor','b',...
    'MarkerFaceColor',[0.5,0.5,0.5])%'--sg'�ȼ���'s--g','sg--'�����У���˳���޹�

%%
x = linspace(0,10,150);
y = cos(5*x);
plot(x,y,'Color',[0,0.7,0.9])
title('2-D Line Plot')
xlabel('x')
ylabel('cos(5x)')

%%
t = 0:seconds(30):minutes(3);
y = rand(1,7);
plot(t,y,'DurationTickFormat','mm:ss')

%%
x = linspace(-pi,pi);
y1 = sin(x);
plot(x,y1)
hold on
y2 = cos(x);
plot(x,y2)
hold off

%%
x = linspace(0,3*pi,200);
y = cos(x) + rand(1,200);  
scatter(x,y)

%%
x = linspace(0,3*pi,200);
y = cos(x) + rand(1,200);
sz = linspace(1,100,200);
scatter(x,y,sz)

%%
x = linspace(0,3*pi,200);
y = cos(x) + rand(1,200);
c = linspace(1,10,length(x));
scatter(x,y,[],c)

%%
x = linspace(0,3*pi,200);
y = cos(x) + rand(1,200);
sz = 25;
c = linspace(1,10,length(x));
scatter(x,y,sz,c,'filled')

%%
theta = linspace(0,2*pi,150);
x = sin(theta) + 0.75*rand(1,150);
y = cos(theta) + 0.75*rand(1,150);  
sz = 140;
scatter(x,y,sz,'d')

%%
y = [75 91 105 123.5 131 150 179 203 226 249 281.5];
bar(y)

%%
x = 1900:10:2000;
y = [75 91 105 123.5 131 150 179 203 226 249 281.5];
bar(x,y)

%%
x = [1980 1990 2000];
y = [15 20 -5; 10 -17 21; -10 5 15];
bar(x,y,'stacked')

%%
X = categorical({'Small','Medium','Large','Extra Large'});
X = reordercats(X,{'Small','Medium','Large','Extra Large'});
Y = [10 21 33 52];
bar(X,Y)

%%
x = randn(10000,1);
histogram(x)

%%
x = randn(1000,1);
nbins = 25;
histogram(x,nbins)

%%
x = randn(1000,1);
edges = [-10 -2:0.25:2 10];
histogram(x,edges);

%%
X = 1:3;
labels = {'Taxes','Expenses','Profit'};
pie(X,labels)

%%
X = linspace(0,4*pi,40);
Y = sin(X);
stairs(Y)

%%
theta = 0:0.01:2*pi;
rho = sin(2*theta).*cos(2*theta);
polarplot(theta,rho)

%%
Y = [1 5 3; 3 2 7; 1 5 3; 2 6 1];
area(Y)

%%
subplot(2,2,1);
x = linspace(-3.8,3.8);
y_cos = cos(x);
plot(x,y_cos);
title('Subplot 1: Cosine')
subplot(2,2,2);
y_poly = 1 - x.^2./2 + x.^4./24;
plot(x,y_poly,'g');
title('Subplot 2: Polynomial')
subplot(2,2,[3,4]);
plot(x,y_cos,'b',x,y_poly,'g');
title('Subplot 3 and 4: Both')

