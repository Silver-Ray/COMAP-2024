%%
x = linspace(-2*pi,2*pi);
y1 = sin(x);
y2 = cos(x);
p = plot(x,y1,x,y2);
p(1).LineWidth = 2;
p(2).Marker = '*';

%%
subplot(121)
plot(0:0.01:10,sin(0:0.01:10))
subplot(122)
plot(0:0.01:20,sin(0:0.01:20))
xlabel('x(mm)')
ylabel('y(mm)')
set(gca,'FontName','Times New Roman','FontSize',14)