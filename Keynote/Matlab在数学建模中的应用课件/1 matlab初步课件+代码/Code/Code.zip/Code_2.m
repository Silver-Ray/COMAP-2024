% clear all;clc
%% Section1
D_1=1;
D_2=1;
D_3=1;
D_1(2)
%% Section2
D_4=1;
D_5=1;
%% Section3
D_6=1;
%%
x=0:0.001:10;
y=sin(x);
plot(x,y)
%%