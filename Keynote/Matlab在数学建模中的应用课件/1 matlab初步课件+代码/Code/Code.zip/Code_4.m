computer
eps
realmax
realmin

ones(5e4);
ones(5e4,'single');

d1=int8(4)
d2=uint8(4)
d3=int64(4)
d4=uint64(4)

+'abcd'